/*
 * Copyright (c) 2022-2023.  Katarzyna Fidos
 * All rights reserved.
 */

package com.vishnu.cloudnine.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


/*
 * @created 13/03/2023
 * @project lecture-demo
 * @author Katarzyna Fidos
 */
//@Entity
@Getter
@Setter
@Builder
public class PersonalFormEntity {
//    @Entity(name = "lecture")

//        @Id
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        private String subject;
        private String author;
        private String preface;
        private int week;
}
