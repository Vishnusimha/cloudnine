/*
 * Copyright (c) 2022-2023.  Katarzyna Fidos
 * All rights reserved.
 */

package com.vishnu.cloudnine.service;

import com.vishnu.cloudnine.model.Lecture;
import com.vishnu.cloudnine.util.ErrorCode;
import com.vishnu.cloudnine.util.LectureServiceException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/*
 * @created 09/03/2023
 * @project lecture-demo
 * @author Katarzyna Fidos
 */
@Service
public class PersonalFormService {

	private Map<Integer, Lecture> lectures = new HashMap<>();

	public PersonalFormService() {
		lectures.put(1, createLecture(1, "Ali Intizar", "Introduction to the Web Applications and HTML", "What is the Web?\n" +
				"How is the Web built?\n" +
				"What is W3C and why it is so important?\n" +
				"What are the HTTP, FTP and HTTPS?\n" +
				"What is a URI, URL, IP, and DNS?\n" +
				"What is HTML and where to find it?"));
		lectures.put(2, createLecture(2, "Ali Intizar", "HTML5 and CSSL", "HTML 5\n" +
				"Media Tags\n" +
				"3Schools Tutorial on HTML 5" +
				"Cascading Style Sheets\n" +
				"Why we need CSS and how to create CSS\n" +
				"CSS Rules\n" +
				"W3Schools Tutorial on CSS"));
		lectures.put(3, createLecture(3, "Ali Intizar", "Java Script", "Document Object Models\n" +
				"Java Script\n" +
				"How to create different JS functions\n" +
				"Making Web pages interactive" +
				"Syntax of JavaScript\n" +
				"Variables, functions, classes, objects, …\n" +
				"Dynamic Web Contents\n" +
				"Events Handling and Actions\n" +
				"Forms Validation"));
		lectures.put(4, createLecture(4, "Ali Intizar", "Java Script 2 - DOM-JQuery, AJAX-JSON", "JQuery\n" +
				"JQuery Events\n" +
				"AJQuery Traversing\n" +
				"JSON\n" +
				"Ajax Intro\n" +
				"Bootstrap"));
		lectures.put(5, createLecture(5, "Ali Intizar", "IDE for Web Development, Intro to Server-side Programming", "We will start preparing the environment for\n" +
				"Eclipse IDE\n" +
				"Creating a Dynamic Web Project\n" +
				"Tomcat Web Server"));
		lectures.put(6, createLecture(6, "Ali Intizar", "Relational Database Management Systems and Structured Query Language (SQL)", "What is a relational database?\n" +
				"What are relational Database Management Systems?\n" +
				"SQL Query Language?\n" +
				"How to create a database?\n" +
				"Learn SQL Query Syntax"));
		lectures.put(7, createLecture(7, "Katarzyna Fidos", "Backend Development Introduction", "What are main backend architectures nowadays?\n" +
				"What is Rest?\n" +
				"What is Spring framework?\n" +
				"What is Dependency Injection\n" +
				"How to build and run simple service using SpringBoot?"));
	}

	private Lecture createLecture(int week, String author, String title, String preface) {
		Lecture lecture = new Lecture();
		lecture.setAuthor(author);
		lecture.setTitle(title);
		lecture.setWeek(week);
		lecture.setPreface(preface);
		return lecture;
	}

	public List<Lecture> listLectures() {
		return lectures.values().stream().collect(Collectors.toList());
		
	}
	
	public Lecture addLecture(Lecture lecture) {
		if (lectures.containsKey(lecture.getWeek())){
			throw new LectureServiceException("Lecture for this week already exist", ErrorCode.LECTURE_DUPLICATION);
		}
		lectures.put(lecture.getWeek(), lecture);
		return lecture;
		
	}
}
