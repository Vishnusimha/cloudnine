/*
 * Copyright (c) 2022-2023.  Katarzyna Fidos
 * All rights reserved.
 */

package com.vishnu.cloudnine.mapper;

import com.vishnu.cloudnine.entity.LectureEntity;
import com.vishnu.cloudnine.model.Lecture;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

/*
 * @created 13/03/2023
 * @project lecture-demo
 * @author Katarzyna Fidos
 */
@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface PersonalFormMapper {


    @Mapping(source = "subject", target = "title")
    Lecture entityToDto(LectureEntity entity);

    @Mapping(source = "title", target = "subject")
    LectureEntity  toEntity(Lecture lectureModel);
}
