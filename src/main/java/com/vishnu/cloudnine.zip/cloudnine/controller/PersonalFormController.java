/*
 * Copyright (c) 2022-2023.  Katarzyna Fidos
 * All rights reserved.
 */

package com.vishnu.cloudnine.controller;

import com.vishnu.cloudnine.model.Lecture;
import com.vishnu.cloudnine.service.LectureService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/*
 * @created 05/03/2023
 * @project lecture-demo
 * @author Katarzyna Fidos
 */

@RestController
@RequestMapping("/lecture")
public class PersonalFormController {

    private final LectureService service;

    public PersonalFormController(LectureService service) {
        this.service = service;
    }

    @GetMapping
    @CrossOrigin(origins = "*")
    public ResponseEntity<List<Lecture>> listLectures() {
        return ResponseEntity.ok(service.listLectures());
    }

    @PostMapping
    @CrossOrigin(origins = "*")
    public ResponseEntity<Void> createLecture(@RequestBody @Valid @NotNull Lecture lecture) {
        service.addLecture(lecture);
        return ResponseEntity.status(HttpStatusCode.valueOf(201)).build();

    }
//	@DeleteMapping
//	@PutMapping
//	@PatchMapping
}
