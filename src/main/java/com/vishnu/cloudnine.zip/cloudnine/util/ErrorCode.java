/*
 * Copyright (c) 2022-2023.  Katarzyna Fidos
 * All rights reserved.
 */

package com.vishnu.cloudnine.util;

import org.springframework.http.HttpStatus;

/*
 * @created 09/03/2023
 * @project lecture-demo
 * @author Katarzyna Fidos
 */
public enum ErrorCode {

    LECTURE_DUPLICATION(HttpStatus.BAD_REQUEST),
    INVALID_USER_REQUEST(HttpStatus.BAD_REQUEST),
    UNEXPECTED_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR),
    MAIL_SENDING_ERROR(HttpStatus.BAD_REQUEST),
    MAIL_CLIENT_SENDING_ERROR(HttpStatus.INTERNAL_SERVER_ERROR);
    private final HttpStatus status;
    ErrorCode(HttpStatus status) {
        this.status = status;
    }


    public HttpStatus getHttpStatus() {
        return this.status;
    }

    public String getCodeName() {
        return name();
    }
}
